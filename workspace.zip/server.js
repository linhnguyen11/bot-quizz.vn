// # SimpleServer
// A simple chat bot server
var logger = require('morgan');
var http = require('http');
var bodyParser = require('body-parser');
var express = require('express');
var router = express();

var app = express();
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));
var server = http.createServer(app);
var request = require("request");

app.get('/', (req, res) => {
  res.send("Home page. Server running okay.");
});

// Đây là đoạn code để tạo Webhook
app.get('/webhook', function(req, res) {
  if (req.query['hub.verify_token'] === 'ma_xac_minh_cua_ban') {
    res.send(req.query['hub.challenge']);
  }
  res.send('Error, wrong validation token');
});

// Xử lý khi có người nhắn tin cho bot
app.post('/webhook', function(req, res) {
  var entries = req.body.entry;
  for (var entry of entries) {
    var messaging = entry.messaging;
    for (var message of messaging) {
      var senderId = message.sender.id;
      if (message.optin) {
          receivedAuthentication(message);
        } else if (message.message) {
          receivedMessage(message);
        } else if (message.delivery) {
          receivedDeliveryConfirmation(message);
        } else if (message.postback) {
          receivedPostback(message);
        } else if (message.read) {
          receivedMessageRead(message);
        } else if (message.account_linking) {
          receivedAccountLink(message);
        } else {
          console.log("Webhook received unknown messagingEvent: ", message);
        }
    }
  }

  res.status(200).send("OK");
});


// Gửi thông tin tới REST API để trả lời
/*
 * Authorization Event
 *
 * The value for 'optin.ref' is defined in the entry point. For the "Send to 
 * Messenger" plugin, it is the 'data-ref' field. Read more at 
 * https://developers.facebook.com/docs/messenger-platform/webhook-reference/authentication
 *
 */
function receivedAuthentication(event) {
  var senderID = event.sender.id;
  var recipientID = event.recipient.id;
  var timeOfAuth = event.timestamp;

  // The 'ref' field is set in the 'Send to Messenger' plugin, in the 'data-ref'
  // The developer can set this to an arbitrary value to associate the 
  // authentication callback with the 'Send to Messenger' click event. This is
  // a way to do account linking when the user clicks the 'Send to Messenger' 
  // plugin.
  var passThroughParam = event.optin.ref;

  console.log("Received authentication for user %d and page %d with pass " +
    "through param '%s' at %d", senderID, recipientID, passThroughParam, 
    timeOfAuth);

  // When an authentication is received, we'll send a message back to the sender
  // to let them know it was successful.
  sendTextMessage(senderID, "Authentication successful");
}

/*
 * Message Event
 *
 * This event is called when a message is sent to your page. The 'message' 
 * object format can vary depending on the kind of message that was received.
 * Read more at https://developers.facebook.com/docs/messenger-platform/webhook-reference/message-received
 *
 * For this example, we're going to echo any text that we get. If we get some 
 * special keywords ('button', 'generic', 'receipt'), then we'll send back
 * examples of those bubbles to illustrate the special message bubbles we've 
 * created. If we receive a message with an attachment (image, video, audio), 
 * then we'll simply confirm that we've received the attachment.
 * 
 */
function receivedMessage(event) {
  var senderID = event.sender.id;
  var recipientID = event.recipient.id;
  var timeOfMessage = event.timestamp;
  var message = event.message;

  console.log("Received message for user %d and page %d at %d with message:", 
    senderID, recipientID, timeOfMessage);
  console.log(JSON.stringify(message));

  var isEcho = message.is_echo;
  var messageId = message.mid;
  var appId = message.app_id;
  var metadata = message.metadata;

  // You may get a text or attachment but not both
  var messageText = message.text;
  var messageAttachments = message.attachments;
  var quickReply = message.quick_reply;

  if (isEcho) {
    // Just logging message echoes to console
    console.log("Received echo for message %s and app %d with metadata %s", 
      messageId, appId, metadata);
    return;
  } else if (quickReply) {
    var quickReplyPayload = quickReply.payload;
    console.log("Quick reply for message %s with payload %s",
      messageId, quickReplyPayload);

    sendTextMessage(senderID, "Quick reply tapped");
    return;
  }

  if (messageText) {

    // If we receive a text message, check to see if it matches any special
    // keywords and send back the corresponding example. Otherwise, just echo
    // the text we received.
    if (messageText.split(" ").some(function(w){return w === 'hello' || w === 'hi' || w === 'chao' || w === 'chào' || w === 'Xinchao' || w === 'hey' || w === 'help'})==true){
        sendHelloMessage(senderID, messageText);
    }else if(messageText.split(" ").some(function(w){return w === 'quiz' || w === 'tính' || w === 'quiziq'})==true){
        sendTextMessage(senderID," Đợi xíu có ngay cho sếp !");
        setTimeout(function(){
          sendQuizMessage(senderID,messageText);
        },1000);
    }else if(messageText.split(" ").some(function(w){return w === 'choi' || w === 'chơi' || w === 'Chơi'})==true){
        sendTextMessage(senderID," Đợi xíu có ngay cho sếp !");
        setTimeout(function(){
          sendButtonMessage(senderID);
        },1000);
    }else if(messageText.split(" ").some(function(w){return w === 'ngu' || w === 'dốt' || w === 'stupid' || w == 'đù'})==true){
        sendTextMessage(senderID," Ngu là viết tắt của never give up !!");
        setTimeout(function(){
          sendTextMessage(senderID, "Ad không có ngu đâu nhá, ngu tại con bot thôi ^^");
        },1000);
    }else if(messageText.split(" ").some(function(w){return w === 'ad' || w === 'admin' || w === 'add' || w === 'Ad' || w === 'AD'})==true){
        sendTextMessage(senderID," Bạn muốn biết ad là ai à! Có ngay!");
        setTimeout(function(){
          sendTextMessage(senderID, "Ad là người thông minh, đức độ, đẹp trai, ga lăng, giàu lòng nhân ái ! ^^");
        },2000);
    }else if(messageText.split(" ").some(function(w){return w === 'tks' || w === 'ơn' || w === 'thanks' || w == 'cảm'})==true){
        sendTextMessage(senderID," Không có gì! Lần sau nhớ chơi tiếp nha :))");
    }else if(messageText.split(" ").some(function(w){return (w === 'đang' || w === 'lam' || w == 'gì')})==true && messageText.split(" ").some(function(w){return (w === 'dang' || w === 'làm' || w == 'gi')})==true){
        sendTextMessage(senderID," Dạ e đang ngồi chơi quiz, bạn có muốn chơi không ?");
    }else if(messageText.split(" ").some(function(w){return w === 'co' || w === 'có' || w == 'yes' || w === 'vâng'})==true){
        sendTextMessage(senderID," OK! Có ngay cho sếp !");
        setTimeout(function() {
            sendQuizMessage(senderID,messageText);
        },1000);
    }else if(messageText.split(" ").some(function(w){return w === 'bot' || w === 'Bot' || w === 'bót' || w == 'pot'})==true){
        sendTextMessage(senderID," Bot đây ! Kêu gì ?");
    }else if(messageText.split(" ").some(function(w){return w === 'đm' || w === 'dm' || w === 'dkm' || w == 'dcm' || w === 'vkl'})==true){
        sendTextMessage(senderID," Ê mày, không được tục tĩu nhá!");
    }else if(messageText.split(" ").some(function(w){return w === 'hihi' || w === 'ahihi'})==true){
        sendTextMessage(senderID," hihi là điệu cười của kẻ biến thái ^^");
    }else if(messageText.split(" ").some(function(w){return w === 'haha' || w === 'Haha' || w === 'kaka' || w == ':)'})==true){
        sendTextMessage(senderID," Cười gì mày !");
    }else if(messageText.split(" ").some(function(w){return w === 'cứu' || w === 'Giúp' || w === 'Cứu' || w == 'Giúp'})==true){
        sendTextMessage(senderID," Có chuyện gì với bạn vậy? Kể mình nghe coi.");
    }else{
      sendTextMessage(senderID," BOT chưa hiểu ý bạn nói, bạn thông cảm nhé !");
    }
    
    // switch (messageText) {
    //   case 'hello':
    //     sendHelloMessage(senderID, messageText);
    //     break;
        
    //   case 'image':
    //     sendImageMessage(senderID);
    //     break;
        
    //   case 'quiz':
    //     sendQuizMessage(senderID);
    //     break;
        
    //   case 'gif':
    //     sendGifMessage(senderID);
    //     break;

    //   case 'audio':
    //     sendAudioMessage(senderID);
    //     break;

    //   case 'file':
    //     sendFileMessage(senderID);
    //     break;

    //   case 'button':
    //     sendButtonMessage(senderID);
    //     break;

    //   case 'generic':
    //     sendGenericMessage(senderID);
    //     break;

    //   case 'receipt':
    //     sendReceiptMessage(senderID);
    //     break;

    //   case 'quick reply':
    //     sendQuickReply(senderID);
    //     break;        

    //   case 'read receipt':
    //     sendReadReceipt(senderID);
    //     break;        

    //   default:
    //     sendTextMessage(senderID, messageText);
    // }
  } else if (messageAttachments) {
    sendTextMessage(senderID, "Message with attachment received");
  }
}

/*
 * Delivery Confirmation Event
 *
 * This event is sent to confirm the delivery of a message. Read more about 
 * these fields at https://developers.facebook.com/docs/messenger-platform/webhook-reference/message-delivered
 *
 */
function receivedDeliveryConfirmation(event) {
  var senderID = event.sender.id;
  var recipientID = event.recipient.id;
  var delivery = event.delivery;
  var messageIDs = delivery.mids;
  var watermark = delivery.watermark;
  var sequenceNumber = delivery.seq;

  if (messageIDs) {
    messageIDs.forEach(function(messageID) {
      console.log("Received delivery confirmation for message ID: %s", 
        messageID);
    });
  }

  console.log("All message before %d were delivered.", watermark);
}

/*
 * Postback Event
 *
 * This event is called when a postback is tapped on a Structured Message. 
 * https://developers.facebook.com/docs/messenger-platform/webhook-reference/postback-received
 * 
 */
function receivedPostback(event) {
  var senderID = event.sender.id;
  var recipientID = event.recipient.id;
  var timeOfPostback = event.timestamp;

  // The 'payload' param is a developer-defined field which is set in a postback 
  // button for Structured Messages. 
  var payload = event.postback.payload;

  console.log("Received postback for user %d and page %d with payload '%s' " + 
    "at %d", senderID, recipientID, payload, timeOfPostback);

  // When a postback is called, we'll send a message back to the sender to 
  // let them know it was successful
  sendTextMessage(senderID, "Postback called");
}

/*
 * Message Read Event
 *
 * This event is called when a previously-sent message has been read.
 * https://developers.facebook.com/docs/messenger-platform/webhook-reference/message-read
 * 
 */
function receivedMessageRead(event) {
  var senderID = event.sender.id;
  var recipientID = event.recipient.id;

  // All messages before watermark (a timestamp) or sequence have been seen.
  var watermark = event.read.watermark;
  var sequenceNumber = event.read.seq;

  console.log("Received message read event for watermark %d and sequence " +
    "number %d", watermark, sequenceNumber);
}

/*
 * Account Link Event
 *
 * This event is called when the Link Account or UnLink Account action has been
 * tapped.
 * https://developers.facebook.com/docs/messenger-platform/webhook-reference/account-linking
 * 
 */
function receivedAccountLink(event) {
  var senderID = event.sender.id;
  var recipientID = event.recipient.id;

  var status = event.account_linking.status;
  var authCode = event.account_linking.authorization_code;

  console.log("Received account link event with for user %d with status %s " +
    "and auth code %s ", senderID, status, authCode);
}

/*
 * Send an image using the Send API.
 *
 */
function sendImageMessage(recipientId) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      attachment: {
        type: "image",
        payload: {
          url: "https://giphy.com/gifs/dog-shiba-inu-typing-mCRJDo24UvJMA"
        }
      }
    }
  };

  callSendAPI(messageData);
}

/*
 * Send an image using the Send API.
 *
 */
function sendHelloMessage(recipientId, messageText) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      text: "Chào bạn! Mình có thể giúp gì cho bạn?",
      metadata: "Chào bạn! Mình có thể giúp gì cho bạn?"
    }
  };
  
  callSendAPI(messageData);
}

/*
 * Send an quiz using the Send API.
 *
 */
function sendQuizMessage(recipientId, messageText) {
    // Gọi API
//       var str = '';
// var options = {
//   host: 'vi.topquiz.co',
//   path: 'view/hot'
// };

// var callback = function(response) {

//   //another chunk of data has been recieved, so append it to `str`
//   response.on('data', function (chunk) {
//     str += chunk;
//   });

//   //the whole response has been recieved, so we just print it out here
//   response.on('end', function () {
//     console.log(str);
//   });
// };

// http.request(options, callback).end();
//     var messageData = {
//       recipient: {
//         id: recipientId
//       },
//     message: {
//       attachment: {
//         type: "template",
//         payload: {
//           template_type: "generic",
//           elements: [{
//             title: str[0].title,
//             subtitle: str[0].desciption,
//             item_url: str[0].type =1 ? 'http://vi.topquiz.co/quiz/iq/' + str[0].pid : 'http://vi.topquiz.co/quiz/' + str[0].pid,               
//             image_url: str[0].thumb.medium,
//             buttons: [{
//               type: "web_url",
//               url: str[0].type =1 ? 'http://vi.topquiz.co/quiz/iq/' + str[0].pid : 'http://vi.topquiz.co/quiz/' + str[0].pid,
//               title: "Chơi Ngay"
//             }, {
//               type: "postback",
//               title: "Để Sau",
//               payload: "Bạn có muốn chơi quiz khác không?",
//             }],
//           }, {
//             title: str[1].title,
//             subtitle: str[1].desciption,
//             item_url: str[1].type =1 ? 'http://vi.topquiz.co/quiz/iq/' + str[1].pid : 'http://vi.topquiz.co/quiz/' + str[1].pid,               
//             image_url: str[1].thumb.medium,
//             buttons: [{
//               type: "web_url",
//               url: str[1].type =1 ? 'http://vi.topquiz.co/quiz/iq/' + str[1].pid : 'http://vi.topquiz.co/quiz/' + str[1].pid,
//               title: "Chơi Ngay"
//             }, {
//               type: "postback",
//               title: "Để Sau",
//               payload: "Bạn có muốn chơi quiz khác không?",
//             }],
//           }]
//         }
//       }
//     }
//   };

//   callSendAPI(messageData);
// End gọi API
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      attachment: {
        type: "template",
        payload: {
          template_type: "generic",
          elements: [{
            title: "Kiểm tra trí thông minh bằng bài toán cấp 1 siêu đơn ",
            subtitle: "Không vượt qua nổi bài kiểm tra này thì về học lại cấp 1 đi nhé!",
            item_url: "http://vi.topquiz.co/quiz/iq/348",               
            image_url:"http://vi.topquiz.co/images/quizz/597ff93364f4ac134e14b11c/thumb_720/Thumb.jpg",
            buttons: [{
              type: "web_url",
              url: "http://vi.topquiz.co/quiz/iq/348",
              title: "Chơi Ngay"
            }, {
              type: "postback",
              title: "Để Sau",
              payload: "Payload for first bubble",
            }],
          }, {
            title: "Cách chọn chỗ ngồi tiết lộ mức độ nam tính-nữ tính trong bạn",
            subtitle: "Bạn có biết con gái thường thích ngồi bên cửa sổ hơn con trai?",
            item_url: "http://vi.topquiz.co/quiz/355",               
            image_url:"http://vi.topquiz.co/images/quizz/59829b0702db622a00a876e9/thumb_720/THUMB.jpg",
            buttons: [{
              type: "web_url",
              url: "http://vi.topquiz.co/quiz/355",
              title: "Chơi Ngay"
            }, {
              type: "postback",
              title: "Để sau",
              payload: "Payload for second bubble",
            }]
          }]
        }
      }
    }
  };

  callSendAPI(messageData);
}
/*
 * Send a Gif using the Send API.
 *
 */
function sendGifMessage(recipientId) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      attachment: {
        type: "image",
        payload: {
          url: "https://giphy.com/gifs/dog-shiba-inu-typing-mCRJDo24UvJMA"
        }
      }
    }
  };

  callSendAPI(messageData);
}
/*
 * Send audio using the Send API.
 *
 */
function sendAudioMessage(recipientId) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      attachment: {
        type: "audio",
        payload: {
          url:"http://sunny.freeservers.com/flowers.MP3"
        }
      }
    }
  };

  callSendAPI(messageData);
}

/*
 * Send a file using the Send API.
 *
 */
function sendFileMessage(recipientId) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      attachment: {
        type: "file",
        payload: {
          url: "vi.topquiz.co/assets/test.txt"
        }
      }
    }
  };

  callSendAPI(messageData);
}

/*
 * Send a text message using the Send API.
 *
 */
function sendTextMessage(recipientId, messageText) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      text: messageText,
      metadata: "DEVELOPER_DEFINED_METADATA"
    }
  };

  callSendAPI(messageData);
}

/*
 * Send a button message using the Send API.
 *
 */
function sendButtonMessage(recipientId) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      attachment: {
        type: "template",
        payload: {
          template_type: "button",
          text: "This is test text",
          buttons:[{
            type: "web_url",
            url: "http://vi.topquiz.co",
            title: "Open Web URL"
          }, {
            type: "postback",
            title: "Trigger Postback",
            payload: "DEVELOPER_DEFINED_PAYLOAD"
          }, {
            type: "phone_number",
            title: "Call Phone Number",
            payload: "+16505551234"
          }]
        }
      }
    }
  };  

  callSendAPI(messageData);
}

/*
 * Send a Structured Message (Generic Message type) using the Send API.
 *
 */
function sendGenericMessage(recipientId) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      attachment: {
        type: "template",
        payload: {
          template_type: "generic",
          elements: [{
            title: "rift",
            subtitle: "Next-generation virtual reality",
            item_url: "https://www.oculus.com/en-us/rift/",               
            image_url:"http://vi.topquiz.co/images/resources/thumb.png",
            buttons: [{
              type: "web_url",
              url: "https://www.oculus.com/en-us/rift/",
              title: "Open Web URL"
            }, {
              type: "postback",
              title: "Call Postback",
              payload: "Payload for first bubble",
            }],
          }, {
            title: "touch",
            subtitle: "Your Hands, Now in VR",
            item_url: "https://www.oculus.com/en-us/touch/",               
            image_url:"http://vi.topquiz.co/images/resources/thumb.png",
            buttons: [{
              type: "web_url",
              url: "https://www.oculus.com/en-us/touch/",
              title: "Open Web URL"
            }, {
              type: "postback",
              title: "Call Postback",
              payload: "Payload for second bubble",
            }]
          }]
        }
      }
    }
  };  

  callSendAPI(messageData);
}

/*
 * Send a receipt message using the Send API.
 *
 */
function sendReceiptMessage(recipientId) {
  // Generate a random receipt ID as the API requires a unique ID
  var receiptId = "order" + Math.floor(Math.random()*1000);

  var messageData = {
    recipient: {
      id: recipientId
    },
    message:{
      attachment: {
        type: "template",
        payload: {
          template_type: "receipt",
          recipient_name: "Peter Chang",
          order_number: receiptId,
          currency: "USD",
          payment_method: "Visa 1234",        
          timestamp: "1428444852", 
          elements: [{
            title: "Oculus Rift",
            subtitle: "Includes: headset, sensor, remote",
            quantity: 1,
            price: 599.00,
            currency: "USD",
            image_url: "http://vi.topquiz.co/images/resources/thumb.png"
          }, {
            title: "Samsung Gear VR",
            subtitle: "Frost White",
            quantity: 1,
            price: 99.99,
            currency: "USD",
            image_url:"http://vi.topquiz.co/images/resources/thumb.png"
          }],
          address: {
            street_1: "1 Hacker Way",
            street_2: "",
            city: "Menlo Park",
            postal_code: "94025",
            state: "CA",
            country: "US"
          },
          summary: {
            subtotal: 698.99,
            shipping_cost: 20.00,
            total_tax: 57.67,
            total_cost: 626.66
          },
          adjustments: [{
            name: "New Customer Discount",
            amount: -50
          }, {
            name: "$100 Off Coupon",
            amount: -100
          }]
        }
      }
    }
  };

  callSendAPI(messageData);
}

/*
 * Send a message with Quick Reply buttons.
 *
 */
function sendQuickReply(recipientId) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      text: "What's your favorite movie genre?",
      quick_replies: [
        {
          "content_type":"text",
          "title":"Action",
          "payload":"DEVELOPER_DEFINED_PAYLOAD_FOR_PICKING_ACTION"
        },
        {
          "content_type":"text",
          "title":"Comedy",
          "payload":"DEVELOPER_DEFINED_PAYLOAD_FOR_PICKING_COMEDY"
        },
        {
          "content_type":"text",
          "title":"Drama",
          "payload":"DEVELOPER_DEFINED_PAYLOAD_FOR_PICKING_DRAMA"
        }
      ]
    }
  };

  callSendAPI(messageData);
}

/*
 * Send a read receipt to indicate the message has been read
 *
 */
function sendReadReceipt(recipientId) {
  console.log("Sending a read receipt to mark message as seen");

  var messageData = {
    recipient: {
      id: recipientId
    },
    sender_action: "mark_seen"
  };

  callSendAPI(messageData);
}

/*
 * Call the Send API. The message data goes in the body. If successful, we'll 
 * get the message id in a response 
 *
 */
function callSendAPI(messageData) {
  request({
    uri: 'https://graph.facebook.com/v2.6/me/messages',
    qs: { access_token: "EAARpMJYwDkwBAHtuFhFzfVFALfTJ6D7fDAGy2hQ4lZBxPqcpBKavolZCSa1fQSMyhJSVqNlOgaZCtXNcoSmKGQpLnbVQLu0ejX96pQ0Qt1Nt9G9VdXAjalMcFZAZBH7qiBPsjxqOlpqf5phKXZAi1BZCzWITtJEAY9nNyhsQKdwhAZDZD"},
    method: 'POST',
    json: messageData

  }, function (error, response, body) {
    if (!error && response.statusCode == 200) {
      var recipientId = body.recipient_id;
      var messageId = body.message_id;

      if (messageId) {
        console.log("Successfully sent message with id %s to recipient %s", 
          messageId, recipientId);
      } else {
      console.log("Successfully called Send API for recipient %s", 
        recipientId);
      }
    } else {
      console.error("Failed calling Send API", response.statusCode, response.statusMessage, body.error);
    }
  });  
}

function sendMessage(senderId, message) {
  request({
    url: 'https://graph.facebook.com/v2.6/me/messages',
    qs: {
      access_token: "EAARpMJYwDkwBAHtuFhFzfVFALfTJ6D7fDAGy2hQ4lZBxPqcpBKavolZCSa1fQSMyhJSVqNlOgaZCtXNcoSmKGQpLnbVQLu0ejX96pQ0Qt1Nt9G9VdXAjalMcFZAZBH7qiBPsjxqOlpqf5phKXZAi1BZCzWITtJEAY9nNyhsQKdwhAZDZD",
    },
    method: 'POST',
    json: {
      recipient: {
        id: senderId
      },
      message: {
        text: message
      },
    }
  });
}

app.set('port', process.env.OPENSHIFT_NODEJS_PORT || process.env.PORT || 3002);
app.set('ip', process.env.OPENSHIFT_NODEJS_IP || process.env.IP || "127.0.0.1");

server.listen(app.get('port'), app.get('ip'), function() {
  console.log("Chat bot server listening at %s:%d ", app.get('ip'), app.get('port'));
});